import os,getpass
import subprocess
os.system("sudo ibmcloud cf push")
